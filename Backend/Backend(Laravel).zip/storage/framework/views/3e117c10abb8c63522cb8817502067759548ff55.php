<?php
$title  = 'Ajout Admin';
?>
	

<?php $__env->startSection('content'); ?>
<div class="main-content" >
    <div class="wrap-content container" id="container">
        <!-- start: PAGE TITLE -->
        <section id="page-title">
            <div class="row">
                <div class="col-sm-8">
                </div>
                <ol class="breadcrumb">
                    <li>
                        <span>Admin</span>
                    </li>
                    <li class="active">
                        <span>Ajout</span>
                    </li>
                </ol>
            </div>
        </section>
        <!-- end: PAGE TITLE -->
        <!-- start: FORM VALIDATION EXAMPLE 1 -->
        <div class="container-fluid container-fullw bg-white">
            <div class="row">
                <div class="col-md-12">
                    <h2>Ajout Admin</h2>

                    <hr>
                    <form action="" method="POST" role="form" id="form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <?php if(!empty($errors->all())): ?>
                                    <div class="errorHandler alert alert-danger">
                                        <i class="fa fa-times-sign"></i> 
                                        Vous avez des erreurs de formulaire. S'il te plaît vérifie le.
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($item); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                <?php endif; ?>

                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label">
                                       Nom <span class="symbol required"></span>
                                    </label>
                                    <input type="text" placeholder="Votre nom" class="form-control" id="firstname" name="nom">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">
                                        Prénom <span class="symbol required"></span>
                                    </label>
                                    <input type="text" placeholder="votre prénom" class="form-control" id="lastname" name="prenom">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">
                                        Email <span class="symbol required"></span>
                                    </label>
                                    <input type="email" placeholder="Votre adresse email" class="form-control" id="email" name="email">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">
                                        Mot de passe <span class="symbol required"></span>
                                    </label>
                                    <input type="password"  placeholder="Votre mot de passe" class="form-control" name="mot_de_passe" id="password">
                                </div>
                                <div class="form-group">
                                    <label class="control-label">
                                        Confirmez Mot de passe <span class="symbol required"></span>
                                    </label>
                                    <input type="password" class="form-control" id="password_again" name="mot_de_passe_confirmation">
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div>
                                    <span class="symbol required"></span>Champs obligatoires
                                    <hr>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <button class="btn btn-primary btn-wide " type="submit">
                                    Ajouter <i class="fa fa-arrow-circle-right"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- end: FORM VALIDATION EXAMPLE 1 -->
    </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kgsexpress/public_html/resources/views/admin/ajoutadmin.blade.php ENDPATH**/ ?>
<?php
header('Location: public/');
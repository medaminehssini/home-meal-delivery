<?php

namespace App\Http\Controllers;

use App\RepasPack;
use Illuminate\Http\Request;

class RepasPackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\RepasPack  $repasPack
     * @return \Illuminate\Http\Response
     */
    public function show(RepasPack $repasPack)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\RepasPack  $repasPack
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RepasPack $repasPack)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\RepasPack  $repasPack
     * @return \Illuminate\Http\Response
     */
    public function destroy(RepasPack $repasPack)
    {
        //
    }
}
